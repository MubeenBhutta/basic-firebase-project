import 'package:firebase_project/splashdata/splashservices.dart';
import 'package:flutter/material.dart';

class splashscreen extends StatefulWidget {
  const splashscreen({super.key});

  @override
  State<splashscreen> createState() => _splashscreenState();
}

class _splashscreenState extends State<splashscreen> {
  splashservices splashservis = splashservices();
  @override
  void initState() {
    super.initState();
    splashservis.checklogin(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
              child: Text(
            'splashscreen',
            style: TextStyle(fontSize: 50),
          ))
        ],
      ),
    );
  }
}
